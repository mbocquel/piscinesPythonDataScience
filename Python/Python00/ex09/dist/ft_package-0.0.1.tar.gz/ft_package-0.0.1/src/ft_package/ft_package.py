def count_in_list(the_list: list, to_find: str):
    return the_list.count(to_find)
